package sample;

public class Controller extends Main {

}
